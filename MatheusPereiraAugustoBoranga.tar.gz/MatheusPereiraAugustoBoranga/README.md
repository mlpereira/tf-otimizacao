# Problema da mochila com grafos de conflito

Para executar o algoritmo, é necessário ter o numpy instalado na máquina.

## Instalação do numpy

Basta ter o pip (https://pip.pypa.io/en/stable/installing/) instalado e executar:
```
make install
```

## Execução

Para executar, rode o comando:
```
python main.py path-do-arquivo-de-entrada
```